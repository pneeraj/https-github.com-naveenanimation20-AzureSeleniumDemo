package lombokTest;

public class Employee {

	public void m1() {
		System.out.println("m1");
	}

	public void m2() {
		System.out.println("m2");
	}

	public void m3() {
		System.out.println("m3");
	}

	public void m4() {
		System.out.println("m4");
	}

	public void m5() {
		System.out.println("m5");
	}

	public void m6() {
		System.out.println("m6");
	}

	public void m7() {
		System.out.println("m7");
	}

	public void m8() {
		System.out.println("m8");
	}

	public void m9() {
		System.out.println("m9");
	}

	public void m10() {
		System.out.println("m10");
	}

}